document.addEventListener("DOMContentLoaded", () => {
  const data = Storage.getUserData();
  const attempts = data.attempts || {};

  document.getElementById("stat-total-time").textContent = `${Math.floor((data.totalTimeSeconds || 0) / 60)}分`;

  const todayStr = new Date().toISOString().split('T')[0];
  let todayCount = 0;
  const todayScores = [];
  Object.entries(attempts).forEach(([qId, att]) => {
    if (att.lastAttempt && att.lastAttempt.startsWith(todayStr)) {
      // その日の最後の確認が今日なら、その問題の定着度を表示に反映。
      todayCount += 1;
      todayScores.push(Mastery.questionScore(att));
    }
  });

  document.getElementById("stat-today-count").innerHTML = `${todayCount}<span class="unit">問</span>`;
  const todayMastery = todayScores.length ? Math.round(todayScores.reduce((a,b) => a+b, 0) / todayScores.length) : 0;
  const masteryEl = document.getElementById("stat-today-mastery");
  if (masteryEl) {
    masteryEl.innerHTML = todayScores.length
      ? `${todayMastery}<span class="unit">%・${Mastery.grade(todayMastery)}</span>`
      : `—<span class="unit">%・—</span>`;
  }
  document.getElementById("stat-streak").innerHTML = `${data.streakDays || 1}<span class="unit">日</span>`;

  const recommendedArea = document.getElementById("recommended-study");
  if (recommendedArea) {
    const ranked = KagakuData.units.map(u => ({
      unit: u,
      score: Mastery.unitScore(u.id, KagakuData.questions, attempts)
    })).sort((a,b) => a.score - b.score);
    const target = ranked[0]?.unit || KagakuData.units[0];
    const score = Mastery.unitScore(target.id, KagakuData.questions, attempts);
    recommendedArea.innerHTML = `
      <div class="panel">
        <div class="eyebrow">定着度からおすすめ</div>
        <h3 style="margin-bottom:8px;">${target.title}</h3>
        <p style="color:var(--text-secondary); margin-bottom:8px;">現在の定着度：<strong>${score}%（${Mastery.grade(score)}）</strong></p>
        <p style="color:var(--text-secondary); margin-bottom:16px;">${target.summary}</p>
        <a href="unit.html?id=${target.id}" class="btn btn-primary">この単元を学習する</a>
      </div>
    `;
  }

  const unitListArea = document.getElementById("unit-progress-list");
  if (unitListArea) {
    unitListArea.innerHTML = KagakuData.units.map(u => {
      const uQs = KagakuData.questions.filter(q => q.unitId === u.id);
      const solved = uQs.filter(q => attempts[q.id]?.count > 0).length;
      const pct = Mastery.unitScore(u.id, KagakuData.questions, attempts);
      const grade = Mastery.grade(pct);
      return `
        <a href="unit.html?id=${u.id}" class="unit-card">
          <div>
            <div class="unit-card-title">${u.title}</div>
            <div class="unit-card-desc">${u.summary}</div>
          </div>
          <div style="text-align:right; min-width:105px;">
            <div style="font-weight:700; color:var(--primary);">${pct}% <span style="font-size:.8rem;">${grade}</span></div>
            <div style="font-size:0.75rem; color:var(--text-muted);">定着度・${solved}/${uQs.length}問確認</div>
          </div>
        </a>
      `;
    }).join("");
  }
});
