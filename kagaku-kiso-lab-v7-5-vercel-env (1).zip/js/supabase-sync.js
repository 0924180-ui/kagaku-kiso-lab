/* 学習者のアカウント・クラウド進捗同期 */
(function(){
  const CFG = { url: window.SUPABASE_URL || '', anonKey: window.SUPABASE_ANON_KEY || '' };
  let client = null;
  let currentUser = null;
  let syncing = false;
  let restored = false;
  let timer = null;

  function configured(){ return !!(CFG.url && CFG.anonKey && window.supabase); }
  function getClient(){
    if (!client && configured()) client = window.supabase.createClient(CFG.url, CFG.anonKey);
    return client;
  }

  async function syncSnapshot(){
    const c = getClient();
    if (!c || !currentUser || !window.Storage || !window.Mastery || !window.KagakuData) return;
    if (syncing) return;
    syncing = true;
    try {
      const data = Storage.getUserData();
      const unitMastery = {};
      (KagakuData.units || []).forEach(u => {
        unitMastery[u.id] = Mastery.unitScore(u.id, KagakuData.questions, data.attempts || {});
      });
      const values = Object.values(data.attempts || {});
      const mastery = values.length ? Math.round(values.reduce((a,b)=>a+Mastery.questionScore(b),0)/values.length) : 0;
      const attemptCount = values.reduce((a,b)=>a+(Number(b.count)||0),0);
      const lastStudy = data.lastStudyDate ? new Date(data.lastStudyDate + 'T23:59:59').toISOString() : null;
      const payload = {
        user_id: currentUser.id,
        mastery,
        attempt_count: attemptCount,
        total_time_seconds: Number(data.totalTimeSeconds)||0,
        last_study_at: lastStudy,
        unit_mastery: unitMastery,
        data,
        updated_at: new Date().toISOString()
      };
      const { error } = await c.from('progress_snapshots').upsert(payload, { onConflict:'user_id' });
      if (error) console.warn('クラウド同期に失敗:', error.message);
    } finally { syncing = false; }
  }

  function queueSync(){
    if (!currentUser || !restored) return;
    clearTimeout(timer);
    timer = setTimeout(() => syncSnapshot(), 350);
  }

  async function restoreSnapshot(){
    const c = getClient();
    if (!c || !currentUser || !window.Storage) { restored = true; return; }
    try {
      const { data: row, error } = await c.from('progress_snapshots').select('data').eq('user_id', currentUser.id).maybeSingle();
      if (error) { console.warn('クラウド進捗の取得に失敗:', error.message); restored = true; return; }
      if (row && row.data && typeof row.data === 'object') Storage.saveUserData(row.data, { skipSync:true });
      restored = true;
    } catch(e) {
      console.warn('クラウド進捗の復元に失敗:', e);
      restored = true;
    }
  }

  async function refreshAuth(){
    const c = getClient();
    if (!c) return null;
    const { data } = await c.auth.getSession();
    currentUser = data.session?.user || null;
    if (currentUser) await restoreSnapshot();
    return currentUser;
  }

  async function signIn(email, password){
    const c = getClient();
    if (!c) throw new Error('Supabaseの設定がありません。');
    return c.auth.signInWithPassword({ email, password });
  }

  async function signUp(email, password, displayName){
    const c = getClient();
    if (!c) throw new Error('Supabaseの設定がありません。');
    return c.auth.signUp({ email, password, options:{ data:{ display_name: displayName || '学習者' } } });
  }

  async function signOut(){
    const c = getClient();
    if (c) await c.auth.signOut();
    currentUser = null; restored = false;
  }

  function user(){ return currentUser; }
  function isConfigured(){ return configured(); }

  window.KagakuCloud = { getClient, configured:isConfigured, user, signIn, signUp, signOut, syncSnapshot, queueSync, refreshAuth };

  document.addEventListener('DOMContentLoaded', async () => {
    const c = getClient();
    if (!c) return;
    c.auth.onAuthStateChange(async (_event, session) => {
      currentUser = session?.user || null;
      restored = false;
      if (currentUser) await restoreSnapshot();
      document.dispatchEvent(new CustomEvent('kagaku-auth-change', { detail:{ user:currentUser } }));
    });
    await refreshAuth();
    document.dispatchEvent(new CustomEvent('kagaku-auth-change', { detail:{ user:currentUser } }));
  });
})();
