/* 管理者ダッシュボード: Supabase Auth + RLS 前提 */
const ADMIN_CONFIG = (() => {
  // setup.htmlで保存したローカル設定を管理者画面でも読み込む
  try {
    const saved = JSON.parse(localStorage.getItem('kagaku_lab_supabase_config') || '{}');
    return {
      url: window.SUPABASE_URL || saved.url || "",
      anonKey: window.SUPABASE_ANON_KEY || saved.anonKey || ""
    };
  } catch (e) {
    return { url: window.SUPABASE_URL || "", anonKey: window.SUPABASE_ANON_KEY || "" };
  }
})();
let supabaseClient = null;
let allStudents = [];
let allSnapshots = [];
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
function grade(v){ return Mastery.grade(Number(v)||0); }
function fmtTime(sec){sec=Number(sec)||0;const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60);return h?`${h}時間${m}分`:`${m}分`;}
function isToday(date){if(!date)return false;const d=new Date(date),n=new Date();return d.getFullYear()===n.getFullYear()&&d.getMonth()===n.getMonth()&&d.getDate()===n.getDate();}
function fmtDate(date){if(!date)return '—';return new Date(date).toLocaleString('ja-JP',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});}
function setup(){
  if(!ADMIN_CONFIG.url||!ADMIN_CONFIG.anonKey){$('login-status').textContent='Supabaseの接続設定がありません。js/supabase-config.jsを設定してください。';$('login-status').className='status danger-status';$('login-form').style.display='none';return;}
  supabaseClient=window.supabase.createClient(ADMIN_CONFIG.url,ADMIN_CONFIG.anonKey);
  supabaseClient.auth.onAuthStateChange((_event, session) => {
    if (session) enter(session);
  });
  supabaseClient.auth.getSession().then(({data})=>{
    if (data.session) enter(data.session);
  });
}
async function login(e){e.preventDefault();if(!supabaseClient)return;$('login-status').textContent='ログインしています…';const {error}=await supabaseClient.auth.signInWithPassword({email:$('login-email').value.trim(),password:$('login-password').value});if(error){$('login-status').textContent='ログインできませんでした。';$('login-status').className='status danger-status';}}
async function enter(session){
  const {data:profile,error}=await supabaseClient.from('profiles').select('display_name,role').eq('id',session.user.id).maybeSingle();
  if(error||!profile||profile.role!=='admin'){await supabaseClient.auth.signOut();$('login-status').textContent='このアカウントには管理者権限がありません。';$('login-status').className='status danger-status';return;}
  $('login-view').hidden=true;$('admin-view').hidden=false;$('admin-subtitle').textContent=`ログイン中: ${profile.display_name||session.user.email||'管理者'}`;await loadData();
}
async function loadData(){
  $('admin-status').textContent='データを読み込んでいます…';
  const [profiles,snaps]=await Promise.all([
    supabaseClient.from('profiles').select('id,display_name,email,role,created_at').eq('role','student').order('created_at',{ascending:false}),
    supabaseClient.from('progress_snapshots').select('user_id,mastery,attempt_count,total_time_seconds,last_study_at,unit_mastery,data,updated_at').order('updated_at',{ascending:false})
  ]);
  if(profiles.error||snaps.error){$('admin-status').textContent='データを取得できませんでした。RLS設定とテーブル設定を確認してください。';$('admin-status').className='status danger-status';return;}
  allStudents=profiles.data||[];allSnapshots=snaps.data||[];render();$('admin-status').textContent=`${allStudents.length}人分のデータを表示中`;
}
function latestByUser(){const map=new Map();for(const s of allSnapshots){if(!map.has(s.user_id))map.set(s.user_id,s);}return map;}
function render(){const map=latestByUser();const rows=allStudents.map(u=>({u,s:map.get(u.id)||{mastery:0,attempt_count:0,total_time_seconds:0,last_study_at:null,unit_mastery:{},data:{}}}));const active=rows.filter(x=>isToday(x.s.last_study_at)).length;const avg=rows.length?Math.round(rows.reduce((a,x)=>a+Number(x.s.mastery||0),0)/rows.length):0;const review=rows.filter(x=>Number(x.s.mastery||0)<60).length;$('a-users').textContent=rows.length;$('a-active').textContent=active;$('a-mastery').textContent=`${avg}% ${grade(avg)}`;$('a-review').textContent=review;renderStudents(rows);renderUnits(rows);renderRecent();}
function renderStudents(rows){
  const q=$('student-search').value.trim().toLowerCase(),f=$('student-filter').value;
  const filtered=rows.filter(x=>{const text=`${x.u.display_name||''} ${x.u.email||''}`.toLowerCase();if(q&&!text.includes(q))return false;if(f==='review'&&Number(x.s.mastery||0)>=60)return false;if(f==='active'&&!isToday(x.s.last_study_at))return false;return true;});
  $('student-tbody').innerHTML=filtered.length?filtered.map(x=>{const m=Math.round(Number(x.s.mastery||0)),g=grade(m);return `<tr><td><button class="student-link" data-user-id="${esc(x.u.id)}"><strong>${esc(x.u.display_name||'名前未設定')}</strong></button><br><span class="muted">${esc(x.u.email||'')}</span></td><td><span class="badge badge-${g.toLowerCase()}">${m}%・${g}</span></td><td>${Number(x.s.attempt_count||0)}問</td><td>${fmtTime(x.s.total_time_seconds)}</td><td>${fmtDate(x.s.last_study_at)}</td></tr>`;}).join(''):`<tr><td colspan="5" class="empty">該当する学習者はいません。</td></tr>`;
  document.querySelectorAll('.student-link').forEach(btn=>btn.addEventListener('click',()=>showStudent(btn.dataset.userId)));
}
function renderUnits(rows){const totals={};for(const x of rows){const um=x.s.unit_mastery||{};for(const [id,v] of Object.entries(um)){if(!totals[id])totals[id]=[];totals[id].push(Number(v)||0);}}$('unit-bars').innerHTML=KagakuData.units.map(u=>{const vals=totals[u.id]||[];const v=vals.length?Math.round(vals.reduce((a,b)=>a+b,0)/vals.length):0;return `<div class="unit-row"><div><div class="unit-name">${esc(u.title)}</div><div class="progress"><i style="width:${v}%"></i></div></div><div class="unit-score">${v}%・${grade(v)}</div></div>`;}).join('');}
function renderRecent(){const items=allSnapshots.slice(0,8).map(s=>{const u=allStudents.find(x=>x.id===s.user_id);return `<div class="recent-item"><div><strong>${esc(u?.display_name||u?.email||'学習者')}</strong><br><span class="muted">定着度 ${Math.round(Number(s.mastery||0))}%</span></div><span class="muted">${fmtDate(s.updated_at||s.last_study_at)}</span></div>`;});$('recent-list').innerHTML=items.length?items.join(''):'<div class="empty">まだ学習データがありません。</div>';}
function showStudent(userId){
  const u=allStudents.find(x=>x.id===userId),s=latestByUser().get(userId);if(!u)return;
  const m=Math.round(Number(s?.mastery||0)),data=s?.data||{},attempts=data.attempts||{};
  const unitRows=KagakuData.units.map(unit=>`<div class="detail-unit"><span>${esc(unit.title)}</span><strong>${Math.round(Number(s?.unit_mastery?.[unit.id]||0))}%</strong></div>`).join('');
  const weak=KagakuData.questions.map(q=>({q,score:Mastery.questionScore(attempts[q.id])})).filter(x=>attempts[x.q.id]&&x.score<60).sort((a,b)=>a.score-b.score).slice(0,8);
  const weakHtml=weak.length?weak.map(x=>`<li>${esc(x.q.question||x.q.text||x.q.title||x.q.id)} <strong>${x.score}%</strong></li>`).join(''):'<li>現在、特に優先度の高い問題はありません。</li>';
  $('detail-content').innerHTML=`<div class="detail-head"><div><div class="eyebrow">学習者詳細</div><h2>${esc(u.display_name||'名前未設定')}</h2><p class="muted">${esc(u.email||'')}</p></div><button class="btn btn-outline btn-sm" id="close-detail">閉じる</button></div><div class="detail-stats"><div><span>総合定着度</span><strong>${m}%・${grade(m)}</strong></div><div><span>確認問題</span><strong>${Number(s?.attempt_count||0)}問</strong></div><div><span>学習時間</span><strong>${fmtTime(s?.total_time_seconds)}</strong></div><div><span>最終学習</span><strong>${fmtDate(s?.last_study_at)}</strong></div></div><h3>単元別定着度</h3><div class="detail-units">${unitRows}</div><h3>優先して復習したい問題</h3><ol class="weak-list">${weakHtml}</ol>`;
  $('student-detail').hidden=false;$('close-detail').onclick=()=>{$('student-detail').hidden=true};
}
$('login-form').addEventListener('submit',login);$('logout-btn').addEventListener('click',async()=>{await supabaseClient.auth.signOut();location.reload()});$('refresh-btn').addEventListener('click',loadData);$('student-search').addEventListener('input',render);$('student-filter').addEventListener('change',render);setup();
